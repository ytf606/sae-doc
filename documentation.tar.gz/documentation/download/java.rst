Java资源下载
##################

本地开发环境
================

-  `sae-local-1.1.0.jar 下载 <http://sae4java.sinaapp.com/lib/sae-local-1.1.0.jar>`_
-  `依赖包 下载 <http://sae4java.sinaapp.com/lib/sae-1.1.0-depend.zip>`_ 本地模拟服务依赖包
-  `sae-1.1.0-all.zip 下载 <http://sae4java.sinaapp.com/lib/sae-1.1.0-all.zip>`_ 包含全部jar包

Eclipse插件
==============

下载地址： `sae-eclipse.zip 下载 <http://sae4java.sinaapp.com/eclipse/sae-eclipse.zip>`_

其他资源
=============

Play Framework 需要的 `Play-1.2.5.jar 下载 <http://sae4java.sinaapp.com/lib/play-1.2.5.jar>`_

