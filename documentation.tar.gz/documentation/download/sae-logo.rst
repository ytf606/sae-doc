SAE图标及素材
##############

欢迎大家将SAE的推广Logo放到您的网站（应用）的合适位置。

由于SAE提供的是云计算服务，不同于一般的空间提供商，所以大家在添加SAE的推广链接时，要么不写"XXX服务商"，要么写"云计算服务商"，但请不要写成"空间提供商"。谢谢各位的支持！

对于嵌入推广Logo的应用，SAE会不定期赠送一些云豆作为奖励！

==============   =========   ===============================================================================
说明             图片        下载地址
==============   =========   ===============================================================================
新浪云计算标志   |image0|    `png下载 <../_static/sinacloud.png>`__ `psd下载 <../_static/sinacloud.psd>`__
新浪SAE标志      |image1|    `png下载 <../_static/sae.png>`__ `psd下载 <../_static/sae.psd>`__
==============   =========   ===============================================================================

.. |image0| image:: /images/sinacloud.png
.. |image1| image:: /images/sae.png

=================== ==========  =======================================
说明                Logo图片    代码样例
=================== ==========  =======================================
125X35px 无边框png  |image8|    div{scrollbar-arrow-color:buttontext}
117X12px 透明gif    |image9|    div{scrollbar-arrow-color:buttontext}
120X33px 透明gif    |image10|   div{scrollbar-arrow-color:buttontext}
=================== ==========  =======================================

.. |image8| image:: /images/poweredby-125x35px.png
.. |image9| image:: /images/poweredby-117x12px.gif
.. |image10| image:: /images/poweredby-120x33px.png
