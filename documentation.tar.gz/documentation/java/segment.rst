.. include:: ../services/segment.rst

API使用手册
============

.. 这里写API Reference或者贴对应服务的API Reference的链接

使用示例
============

.. 这里贴示例
