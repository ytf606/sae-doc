公共资源
============

SAE的为很多流行的开源js/css库提供了CDN加速服务，开发者可以引用我们的js/css库来提升你的应用的访问速度。

-  `[bootstrap] <http://lib.sinaapp.com/?path=/bootstrap>`_
-  `[dojo] <http://lib.sinaapp.com/?path=/dojo>`_
-  `[ext-core] <http://lib.sinaapp.com/?path=/ext-core>`_
-  `[highcharts] <http://lib.sinaapp.com/?path=/highcharts>`_
-  `[jq.mobi] <http://lib.sinaapp.com/?path=/jq.mobi>`_
-  `[jquery] <http://lib.sinaapp.com/?path=/jquery>`_
-  `[jquery-mobile] <http://lib.sinaapp.com/?path=/jquery-mobile>`_
-  `[jquery-ui] <http://lib.sinaapp.com/?path=/jquery-ui>`_
-  `[jquerytools] <http://lib.sinaapp.com/?path=/jquerytools>`_
-  `[mootools] <http://lib.sinaapp.com/?path=/mootools>`_
-  `[prototype] <http://lib.sinaapp.com/?path=/prototype>`_
-  `[qunit] <http://lib.sinaapp.com/?path=/qunit>`_
-  `[scriptaculous] <http://lib.sinaapp.com/?path=/scriptaculous>`_
-  `[swfobject] <http://lib.sinaapp.com/?path=/swfobject>`_
-  `[webfont] <http://lib.sinaapp.com/?path=/webfont>`_
-  `[yui] <http://lib.sinaapp.com/?path=/yui>`_
