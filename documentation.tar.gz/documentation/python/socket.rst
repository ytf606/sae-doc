.. include:: ../services/socket.rst

API使用手册
============

直接使用socket模块即可。目前仅支持AF_INET, SOCK_STREAM连接，暂时不支持异步socket。bind/listen方法无法使用。
