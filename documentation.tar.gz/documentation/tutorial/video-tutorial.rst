视频教程
##############

入门教程
================

.. 连接是死连接，待补


一分钟搭建自己的博客
=====================

.. image:: /images/video-tutorial-create-blog-in-one-minute.png
   :target: `create_blog_in_one_minute`_
   
.. _create_blog_in_one_minute: http://images.sae.sina.com.cn/flash/video/wp/

计数器服务示例
=================

.. image:: /images/video-tutorial-counter.png
   :target: `counter`_

.. _counter: http://images.sae.sina.com.cn/flash/video/counter/

计划任务服务实例
===================

.. 连接是死连接，待补

验证码服务实例
======================

.. 视频太轻佻，第一句话本小姐是怎么回事，咋不说本大小姐呢
